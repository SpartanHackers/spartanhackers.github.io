import React from "react";
import "./background.css"

const Greenback = () => {
    return (
        <div id="background"></div>
    );
}

export default Greenback;