import React from "react";
import "./background.css"

const Reversegreenback = () => {
    return (
        <div id="reverse-background"></div>
    );
}

export default Reversegreenback;