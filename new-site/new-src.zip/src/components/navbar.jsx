import React from "react";
import "./navbar.css"


const Navbar = () => {
    return (
        <nav>
            <a href="index.html">
                <img src="images/Copy of SH DARK.png" class="logo"></img>
            </a>
            <ul>
                <li><a href="about.html">About</a></li>
                <li><a href="join.html">Join Us</a></li>
                <li><a href="schedule.html">Schedule</a></li>
                <li><a href="hackathons.html">Hackathons</a></li>
                <li><a href="workshops.html">Workshops</a></li>
                <li><a href="board.html">EBoard</a></li>
                <li><a href="questions.html">FAQ</a></li>
            </ul>
        </nav>
    );
}

export default Navbar;